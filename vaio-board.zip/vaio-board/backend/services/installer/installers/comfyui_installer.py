# backend/services/installers/comfyui_installer.py
def install_comfyui():
    print("[INSTALL] comfyui_installer.py not implemented yet.")
    return {"status": "stub"}
