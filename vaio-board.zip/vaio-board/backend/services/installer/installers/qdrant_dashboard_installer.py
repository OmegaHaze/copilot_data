# backend/services/installers/qdrant_dashboard_installer.py
def install_qdrant_dashboard():
    print("[INSTALL] qdrant_dashboard_installer.py not implemented yet.")
    return {"status": "stub"}
