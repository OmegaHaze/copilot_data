# backend/services/installers/n8n_installer.py
def install_n8n():
    print("[INSTALL] n8n_installer.py not implemented yet.")
    return {"status": "stub"}
