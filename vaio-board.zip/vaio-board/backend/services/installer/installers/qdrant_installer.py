# backend/services/installers/qdrant_installer.py
def install_qdrant():
    print("[INSTALL] qdrant_installer.py not implemented yet.")
    return {"status": "stub"}
