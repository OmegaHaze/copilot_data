# backend/services/installers/ollama_installer.py

def install_ollama():
    print("[INSTALL] ollama_installer.py not implemented yet.")
    # TODO: download, setup, config
    return {"status": "stub"}
