# backend/services/installers/openwebui_backend_installer.py
def install_openwebui_backend():
    print("[INSTALL] openwebui_backend_installer.py not implemented yet.")
    return {"status": "stub"}
